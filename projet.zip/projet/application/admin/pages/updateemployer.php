<?php
require_once("connexiondb.php");
$id_employer=isset($_POST['id_employer'])?$_POST['id_employer']:0;
$matricule=isset($_POST['matricule'])?$_POST['matricule']:"";
$nom=isset($_POST['nom'])?$_POST['nom']:"";
$prenom=isset($_POST['prenom'])?$_POST['prenom']:"";
$adresse=isset($_POST['adresse'])?$_POST['adresse']:"";
$date_naissance=isset($_POST['date_naissance'])?$_POST['date_naissance']:"";
$telephone=isset($_POST['telephone'])?$_POST['telephone']:"";
$email=isset($_POST['email'])?$_POST['email']:"";
$grade=isset($_POST['grade'])?$_POST['grade']:"";
$daterecrut=isset($_POST['daterecrut'])?$_POST['daterecrut']:"";

$requete="update employer set matricule=? , nom=? , prenom=? , adresse=? , date_naissance=?, telephone=?, email=?, grade=? , daterecrut=? where id_employer=?";
$params=array($matricule,$nom,$prenom,$adresse,$date_naissance,$telephone,$email,$grade,$daterecrut,$id_employer);
$resultat=$pdo->prepare($requete);
$resultat->execute($params);
header('location:employer.php');
?>