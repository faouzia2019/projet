<?php
require_once("connexiondb.php");
$id_travail=isset($_POST['id_travail'])?$_POST['id_travail']:0;
$matricule=isset($_POST['matricule'])?$_POST['matricule']:"";
$nom=isset($_POST['nom'])?$_POST['nom']:"";
$prenome=isset($_POST['prenom'])?$_POST['prenom']:"";
$cause=isset($_POST['cause'])?$_POST['cause']:"";

$requete="update travail set matricule=? , cause=? where id_travail=?";
$params=array($matricule,$cause,$id_travail);
$resultat=$pdo->prepare($requete);
$resultat->execute($params);
header('location:travail.php');
?>