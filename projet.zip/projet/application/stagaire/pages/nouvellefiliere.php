<!DOCTYPE HTML>
<html>
    <head>
        <meta charest="utf-a">
        <tit>Nouvelle filiere </tit>
        <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
         <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
    </head>
    <body>
        <?php include("menu.php");?>
         <div class="container">
         <div class="panel panel-primary margetop" >
            <div class="panel-heading">Veuillez saisir les données de la nouvelle filiere </div>
           
             <div class ="panel-body">
                <form method="post" action="insertfelieres.php" class="form" >
                <div class ="form-group">
                    <label for="niveau">Nom de la filière:</label>
                <input type="text" name="nomF" placeholder=" nom de filière" class="form-control " /></div>
                    <div class="form-group">
                <label for="niveau">Niveau:</label>
                <select name="niveau" class="form-control" id="niveau">
                    
                    <option value="1ER">1ER </option>
                     <option value="2EME">2EME </option>
                     <option value="M">Master </option>
                    <option value="N">Ingenieure </option>
                </select>
                    </div>
                
                    
                <button type ="submit" class="btn btn-success"><span class ="glyphicon glyphicon-save"></span>Enregister..</button> 
            
                </form>
             
            </div>
           
        </div>    
        </div>
    </body>
</html>
