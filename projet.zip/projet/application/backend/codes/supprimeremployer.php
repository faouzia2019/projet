<?php
header("Access-Control-Allow-Origin: *");
include_once('../includes/connexion.php');

if(isset($_GET["id_employer"])) {
    $id=$_GET["id_employer"];
   

    $res = $con->query("SELECT id_employer from employer where id_employer=$id ");
    if($res->num_rows>0){
$requete="delete from employer where id_employer=$id ";

       if( $con->query ( $requete)>0){
    $rep[0]=1;
    
     //   $row=$res->fetch_assoc();
      //  $rep[1]=$row['id'];
    }else {
        $rep[0]=$con->error;
    }}
    else {
    $rep[0]=$con->error; }
    echo json_encode($rep);

   header('location:../../messagesupprimer.php');

}
                       
