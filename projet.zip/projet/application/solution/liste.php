<?php 
session_start();
if(isset($_SESSION['nom'])  && isset($_SESSION['prenom'])){




include('menu.php') ;



?>
<!DOCTYPE html>
<html lang="en">


<div class="col">
<div class="card border-primary mb-3" style="max-width: 40rem;"  >
  <div class="card-header"><H5>Demande de liste de services</H5></div>
  <div class="card-body " align="left">
                <form    id="ajoutliste"  action="../backend/codes/demandeliste.php"  class="formadd" method="POST">
                    
                    
                    <label class="col-md-4"><b>  Matricule</b></label>
                    <input  class="col-md-8 form-control" type="number"  <?php if ($_SESSION['role'] !='1'){?>
                    value="<?php echo $_SESSION['matricule']; ?>" readonly 
                    
                    <?php } ?>placeholder="matricule " name="matricule" required></p>
    
            
                    <label  class="col-md-4"><b>dernier attestation</b></label>
                    <input  class="col-md-8 form-control"type="text" placeholder="dernier_attestation" name="dernier_attestation" required size="64" maxLength="15" minLength="3" ></p>
                    <label  class="col-md-4"><b>cause</b></label>
                    <input  class="col-md-8 form-control"type="text" placeholder="cause" name="cause" required  size="64" maxLength="15" minLength="3"></p>
                    
                   
                    </p>
                      
                            <button type="submit" id='submit' class="btn btn-primary ">Envoyer</button>
                    
                </form>
               
               
               
               
        
      
        
        
    
        </div>
</body>
</html>

<?php 
   } else{
     header('location:./Login/index.html');
   }  
    ?>