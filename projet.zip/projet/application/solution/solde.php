<?php
session_start();

if(1==1){
    include_once('../backend/includes/connexion.php');
    $matricule=recuperer("matricule","employer","   order by matricule",$con);
    $typid=recuperer("id,label","typeconge"," where id=1",$con);
    $today=date("Y-m-d");
    $annee=date("2020");

if(count($matricule)>0){
    for($i=0;$i<count($matricule);$i++){
$mat=$matricule[$i];
    $datem=recuperer("datemise","solde"," where matricule='$mat' and typeconges=1 ORDER BY   annee DESC ",$con);
    $dater=recuperer("daterecrut","employer"," where matricule='$mat'",$con);
    if(count($datem)==0){

        $dateref=date('2020-06-01');
        $datetime1 = new DateTime($dater[0]);
    $datetime2 = new DateTime( $dateref);
        if( $datetime1 >= $datetime2){

            $dateref=$dater[0];
        }
$solde = calculmois($today,$dateref)*3.75;

$req="insert into solde values(
default,
'$mat',
$typid[0],
'$solde',

'$solde',
'$annee',
'$today'

)";
if($con->query($req)){
    $req="insert into solde values(
        default,
        '$mat',
        2,
        '6',
        
        '6',
        '$annee',
        '$today'
        
        )";
        if($con->query($req)){
        
            $req="insert into solde values(
                default,
                '$mat',
                3,
                '30',
                
                '30',
                '$annee',
                '$today'
                
                )";
                if($con->query($req)){ $req="insert into solde values(
                    default,
                    '$mat',
                    4,
                    '0',
                    
                    '0',
                    '$annee',
                    '$today'
                    
                    )";
                    if($con->query($req)){}
                
                    
                }else {
                
                    echo $con->error;
                }
                
        }else {
        
            echo $con->error;
        }
        
    
}else {

    echo $con->error;
}

}else {
$thisyear=date('Y');

$ym= substr( $datem[0],0,4);


if($ym==$thisyear){
    $solde = calculmois($today,$datem[0])*3.75;
    $req="update solde set
     solde=solde+$solde, 
     solde_restante=solde_restante+$solde , 
     datemise='$today'  
      where matricule='$mat' and typeconges=1 and annee=$thisyear ";
        
        if($con->query($req)){}else {
        
            echo $con->error;
        }
    }else {
        $solde1 = calculmois($today,date('Y-01-01'))*3.75;
        $solde2 = calculmois($datem[0],date($ym.'-12-31'))*3.75;
        $req="insert into solde values(
            default,
            '$mat',
            $typid[0],
            '$solde1',
            
            '$solde1',
            '$annee',
            '$today'
            
            )";
            if($con->query($req)){
                $req="update solde set
                solde=solde+$solde2, 
                solde_restante=solde_restante+$solde2 , 
                datemise='".date($ym.'-12-31')."'  
                 where matricule='$mat' and typeconges=1 and annee=$ym ";
                   
                   if($con->query($req)){


                    $req="insert into solde values(
                        default,
                        '$mat',
                        3,
                        '30',
                        
                        '30',
                        '$annee',
                        '$today'
                        
                        )";
                        if($con->query($req)){

                            $req="insert into solde values(
                                default,
                                '$mat',
                                2,
                                '6',
                                
                                '6',
                                '$annee',
                                '$today'
                                
                                )";
                                if($con->query($req)){


                                    $req="insert into solde values(
                                        default,
                                        '$mat',
                                       4,
                                        '0',
                                        
                                        '0',
                                        '$annee',
                                        '$today'
                                        
                                        )";
                                        if($con->query($req)){}
                                }

                        }
                   }else {
                   
                       echo $con->error;
                   }

            }else {
            
                echo $con->error;
            }

    }


}}}
}
 

?>