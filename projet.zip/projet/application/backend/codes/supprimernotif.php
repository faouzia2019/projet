<?php
header("Access-Control-Allow-Origin: *");
include_once('../includes/connexion.php');
//print_r(($_POST));

if(isset($_GET["id_notification"])) {
    $id=$_GET["id_notification"];
   

    $res = $con->query("SELECT id_notification from notification where id_notification=$id ");
    if($res->num_rows>0){
$requete="delete from notification where id_notification=$id ";

       if( $con->query ( $requete)>0){
    $rep[0]=1;
    
     //   $row=$res->fetch_assoc();
      //  $rep[1]=$row['id'];
    }else {
        $rep[0]=$con->error;
    }}
    else {
    $rep[0]=$con->error; }
    echo json_encode($rep);

   

}
                       
?>