<!doctype html>
<!--
	Solution by GetTemplates.co
	URL: https://gettemplates.co
-->
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- awesone fonts css-->
    <link href="css/font-awesome.css" rel="stylesheet" type="text/css">
    <!-- owl carousel css-->
    <link rel="stylesheet" href="owl-carousel/assets/owl.carousel.min.css" type="text/css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- custom CSS -->
    <link rel="stylesheet" href="css/style.css">
    <title>Solution - Free Responsive Agency Template using Bootstrap 4</title>
    <style>

    </style>
</head>
<body>
 <DIV>
<nav class="navbar navbar-expand-lg navbar-light bg-light bg-transparent" id="gtco-main-nav">
    <div class="container"><a class="navbar-brand">ISIMEDNINE</a>
        <button class="navbar-toggler" data-target="#my-nav" onclick="myFunction(this)" data-toggle="collapse"><span
                class="bar1"></span> <span class="bar2"></span> <span class="bar3"></span></button>
        <div id="my-nav" class="collapse navbar-collapse">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item"><a class="nav-link" href="#">Acceuil</a></li>
                <li class="nav-item"><a class="nav-link" href="#services">Service personnel</a></li>
                <li class="nav-item"><a class="nav-link" href="#about">Service PFE</a></li>
                
                <li class="nav-item"><a class="nav-link" href="#contact">Contact</a></li>
            </ul>
            <form class="form-inline my-2 my-lg-0">
                <a href="Login" class="btn btn-outline-dark my-2 my-sm-0 mr-3 text-uppercase">login</a> <a href="#"
                                                                                                       class="btn btn-info my-2 my-sm-0 text-uppercase">sign
                up</a>
            </form>
        </div>
    </div></DIV>   
</nav>
<div class="container-fluid gtco-banner-area">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <form action="inscription1.php" class="formadd" method="POST">
                    <h1>Ajouter Employer</h1>
                    
                    <label class="col-md-4"><b>  Matricule</b></label>
                    <input  class="col-md-8 form-control" type="number" placeholder="matricule " name="matricule" required></p>
    
                    <label  class="col-md-4"  ><b>nom</b></label>
                    <input  class="col-md-8 form-control" type="text" placeholder="nom" name="nom" required size="64" maxLength="15" minLength="3"></p>
                    <label  class="col-md-4"><b>prenom</b></label>
                    <input  class="col-md-8 form-control" type="text" placeholder="prenom" name="prenom" required></p>
                    <label  class="col-md-4"><b>adresse</b></label>
                    <input  class="col-md-8 form-control"type="text" placeholder="adresse" name="adresse" required></p>
                    <label  class="col-md-4"   ><b>date_de_naissance</b></label>
                    <input  class="col-md-8 form-control" type="date" placeholder="date_de_naissance"  id="party"  min="1960-01-01" max="2002-01-01"  name="date_de_naissance" required   ></p>
                    <label  class="col-md-4"><b>telephone</b></label>
                    <input  class="col-md-8 form-control"type="tel" placeholder="telephone" name="telephone" required></p>
                    <label  class="col-md-4"><b>email</b></label>
                    <input  class="col-md-8 form-control"type="email" placeholder="email" name="email" required  pattern=".+@gmail.com" size="30" id="email"  size="64" maxLength="64"  ></p>
                    <label  class="col-md-4"><b>grade</b></label>
                    <input  class="col-md-8 form-control" type="text" placeholder="grade" name="grade" required></p>
    
    
                    <button  class="col-md-12 btn btn-info"type="submit" id='submit'  >Inserer</button></p>
                    
                </form>
               
               
               
               
        
        
        </div>
            <div class="col-md-6">
                <div class="card"><img class="card-img-top img-fluid" src="images/banner-img.png" alt=""></div>
            </div>
        </div>
    </div>
</div><footer class="container-fluid" id="gtco-footer">
    <div class="container">
        <div class="row">
            <!--div class="col-lg-6" id="contact">
                <h4> Contact Us </h4>
                <input type="text" class="form-control" placeholder="Full Name">
                <input type="email" class="form-control" placeholder="Email Address">
                <textarea class="form-control" placeholder="Message"></textarea>
                <a href="#" class="submit-button">READ MORE <i class="fa fa-angle-right" aria-hidden="true"></i></a>
            </div>
            <div class="col-lg-6">
                <div class="row">
                    < div class="col-6">
                        <h4>Company</h4>
                        <ul class="nav flex-column company-nav">
                            <li class="nav-item"><a class="nav-link" href="#">Home</a></li>
                            <li class="nav-item"><a class="nav-link" href="#">Services</a></li>
                            <li class="nav-item"><a class="nav-link" href="#">About</a></li>
                            <li class="nav-item"><a class="nav-link" href="#">News</a></li>
                            <li class="nav-item"><a class="nav-link" href="#">FAQ's</a></li>
                            <li class="nav-item"><a class="nav-link" href="#">Contact</a></li>
                        </ul>
                        <h4 class="mt-5">Fllow Us</h4>
                        <ul class="nav follow-us-nav">
                            <li class="nav-item"><a class="nav-link pl-0" href="#"><i class="fa fa-facebook"
                                                                                      aria-hidden="true"></i></a></li>
                            <li class="nav-item"><a class="nav-link" href="#"><i class="fa fa-twitter"
                                                                                 aria-hidden="true"></i></a></li>
                            <li class="nav-item"><a class="nav-link" href="#"><i class="fa fa-google"
                                                                                 aria-hidden="true"></i></a></li>
                            <li class="nav-item"><a class="nav-link" href="#"><i class="fa fa-linkedin"
                                                                                 aria-hidden="true"></i></a></li>
                        </ul>
                    </div>
                    <div class="col-6">
                        <h4>Services</h4>
                        <ul class="nav flex-column services-nav">
                            <li class="nav-item"><a class="nav-link" href="#">Web Design</a></li>
                            <li class="nav-item"><a class="nav-link" href="#">Graphics Design</a></li>
                            <li class="nav-item"><a class="nav-link" href="#">App Design</a></li>
                            <li class="nav-item"><a class="nav-link" href="#">SEO</a></li>
                            <li class="nav-item"><a class="nav-link" href="#">Marketing</a></li>
                            <li class="nav-item"><a class="nav-link" href="#">Analytic</a></li>
                        </ul>
                    </div -->  
                    <div class="col-12">
                        <p>&copy; 2019. All Rights Reserved. Design by <a href="https://gettemplates.co" target="_blank">GetTemplates</a>.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="js/jquery-3.3.1.slim.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- owl carousel js-->
<script src="owl-carousel/owl.carousel.min.js"></script>
<script src="js/main.js"></script>
</body>
</html>
