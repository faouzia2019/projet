<?php
require_once("connexiondb.php");

$requete=" select id_employer, matricule,nom,prenom,date_naissance,email,telephone,adresse,grade,daterecrut from employer " ;
$resultatC=$pdo->query($requete);
//$nomf=$_Get['5'];
?>


<! DOCTYPE HTML>
<html>
<head>
  <meta charset="utf-8">
    <title>gestion employer</title>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
    </head>
<body> 
    <?php include("menu.php");?>
    <div class="container">
    <div class="panel panel-success  margetop" >
        <div class="panel-heading">  rechercher ...</div>
        <div class="panel-body"> 
            <form method="get" action="ajouteremployer.php" class="form-inline">
                <div class="form-group">
            <input type="text" name="name" placeholder="nom employer " class="form-control"></div>
              Nom:
            
                         
                                             
                      <button type="submit"   value="rechercher..." class="btn btn-success">  
                <span class="glyphicon glyphicon-search" >
                </span></button>
                &nbsp &nbsp 
                          <a href = "ajouteremployer.php"> <span class="glyphicon glyphicon-plus" ></span>      Ajouter Employer  </a>
                
          
          
                    </form>           
                               
            
          
        
        
        </div>
    
    </div>
        <div class="panel panel-primary " >
        <div class="panel-heading">  Liste de employers </div>
        <div class="panel-body">
            <table class="table table-striped table-bordered">
            <thead>
           <tr>
          
             <th>Matricule</th> 
               <th>Nom</th> 
               <th>Prenom</th>   
             <th>Date_naissance</th> 
               <th>email</th>
                 <th>Adresse</th>
                 <th>Telephone</th>
               <th>Grade</th>
               <th>Date_recrutement</th>
                   <th>Action</th> 
                </tr>     
                
                
                </thead>
            <tbody>
                
                <?php while($employer=$resultatC->fetch()){
    
 ?>
             
                <tr>
                     
  <td> <?php echo $employer['matricule'] ?>   </td>
             
       <td> <?php echo $employer['nom'] ?>
                </td>
        <td> <?php echo $employer['prenom'] ?>
                </td>
       <td> <?php echo $employer['date_naissance'] ?>
                </td>
       <td> <?php echo $employer['email'] ?> </td>
               
       <td> <?php echo $employer['adresse'] ?>
                </td>
      <td> <?php echo $employer['telephone'] ?>
                </td> 
                    
                    <td> <?php echo $employer['grade'] ?>
                </td>
                    <td> <?php echo $employer['daterecrut'] ?>
                </td>
                    
                      <td> <a href="editeremployer.php?id_employer=<?php echo $employer['id_employer'] ?>"><span class="glyphicon glyphicon-edit" ></a>
                
                          
                              <a href="imprimeremployer.php " > <span class="glyphicon glyphicon-print" > 
                </span>
                         <a onclick="return confirm('etre vous sur de vouloir supprimer le employer ')" href= "%252520../../../../backend/codes/supprimeremployer.php?id_employer=<?php echo $employer['id_employer'] ?> "> <span class="glyphicon glyphicon-trash" ></a>
               
                </td> 
                </tr>
        <?php } ?>
           
                </tbody>
            
            
            </table>
        
        
        </div>
    
    </div>

    </div>
    </body>
</HTML>