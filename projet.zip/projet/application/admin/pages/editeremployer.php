<?php
require_once("connexiondb.php");
$id_employer=isset($_GET['id_employer'])?$_GET['id_employer']:0;
$requete="select matricule,nom,prenom,adresse,date_naissance,telephone,email,grade,daterecrut from employer where id_employer=$id_employer";

$resultat=$pdo->query($requete);
$employer=$resultat->fetch();
$matricule=$employer['matricule'];
$nom=$employer['nom'];
$prenom=$employer['prenom'];
$adresse=$employer['adresse'];
$telephone=$employer['telephone'];
$date_naissance=$employer['date_naissance'];
$email=$employer['email'];
$grade=$employer['grade'];
$daterecrut=$employer['daterecrut'];
//$nomf=$_Get['5'];
?>

<! DOCTYPE HTML>
<html>
<head>
  <meta charset="utf-8">
    <title>Editez  employer</title>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
    </head>
<body> 
    <?php include("../pages/menu.php");?>
    <div class="container">
                <div class="panel panel-primary  margetop " >
           
                <div class="panel-heading">Modifier les doneés d' employer</div>
        <div class="panel-body"> 
            <form method="post" action="updateemployer.php"  class="form">
                
                 <div class="form-group">
                    <label for="id_employer">id  de employer :<?php echo $id_employer ?> </label>
            <input type="hidden" name="id_employer"  class="form-control"  value="<?php echo $id_employer ?>"/></div>
                
                
               <div class="form-group">
                     <label for="matricule">matricule  de employer :<?php echo $matricule ?> </label>
            <input type="number" name="matricule" placeholder="matricule" class="form-control" value="<?php echo $matricule ?>"/></div>
                
                
                <div class="form-group">
           <label for="nom">Nom de l'employer: <?php echo $nom ?> </label>
            <input type="text" name="nom" placeholder="nom" class="form-control" value="<?php echo $nom ?>"/></div>
          
                <div class="form-group">
             <label for="prenom">Prenom de l'employer: <?php echo $prenom ?></label>
            <input type="text" name="prenom" placeholder="prenom" class="form-control" value="<?php echo $prenom ?>"/></div>
                <div class="form-group">
          
               <label for="nom">Adresse de l'employer: <?php echo $adresse ?> </label>
            <input type="text" name="adresse" placeholder="adresse" class="form-control" value="<?php echo $adresse ?>"/></div>
                
                     <div class="form-group">
                 <label for="nom">telephone:<?php echo $telephone ?></label>
            <input type="number" name="telephone" placeholder="telephone" class="form-control" value="<?php echo $telephone ?>"/></div>
                                       
                <div class="form-group">
                   <label for="nom">date_naissance de l'employer:<?php echo $date_naissance ?></label>
            <input type="date" name="date_naissance" placeholder="date_naissance" class="form-control" value="<?php echo $date_naissance ?>"/></div>
                
                <div class="form-group">
          <label for="nom">email de l'employer: <?php echo $email ?></label>
            <input type="text" name="email" placeholder="email" class="form-control" value="<?php echo $email ?>"/></div>
                
                <div class="form-group">
          <label for="nom">grade de l'employer:<?php echo $grade ?> </label>
            <input type="text" name="grade" placeholder="grade" class="form-control" value="<?php echo $grade ?>"/></div>
                
                <div class="form-group">
          <label for="nom">date de recrutement l'employer:<?php echo $daterecrut ?></label>
            <input type="date" name="daterecrut" placeholder="date_recrutement" class="form-control" value="<?php echo $daterecrut ?>" /></div>
          
                        
                <button type="submit" class="btn-btn-success">
                <span class="glyphicon glyphicon-save"></span> Modifier </button>
                
                     
            
                            
                   </form>
            
          
        
        
        
              
      
                 
                </tbody>
            
            
            </table>
        
        
        </div>
    
    </div>

    </div>
    </body>
</HTML>