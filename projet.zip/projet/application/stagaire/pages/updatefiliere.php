<?php 
require_once("connexiondb.php");
$idf=isset($_POST['idF'])?$_POST['idF']:0;
$nomf=isset($_POST['nomF'])?$_POST['nomF']:"";
$niveau=isset($_POST['niveau'])?$_POST['niveau']:"";            

$requete="update filiere set nomfiliere=?, niveau=? where id_filiere=?";
$params=array($nomf,$niveau,$idf);
$resultat=$pdo->prepare($requete);
$resultat ->execute($params);
header ('location:felieres.php');
?>