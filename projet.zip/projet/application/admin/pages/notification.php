<?php
require_once("connexiondb.php");

$requete=" select id_notification, matricule,date_notification,type_congee from  notification " ;
$resultatC=$pdo->query($requete);
//$nomf=$_Get['5'];
?>


<! DOCTYPE HTML>
<html>
<head>
  <meta charset="utf-8">
    <title>liste de notification </title>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
    </head>
<body> 
    <?php include("menu.php");?>
    <div class="container">
    <div class="panel panel-success  margetop" >
        <div class="panel-heading">  rechercher ...</div>
        <div class="panel-body"> 
            <form method="get" action="" class="form-inline">
                <div class="form-group">
            <input type="text" name="name" placeholder="matricule employer " class="form-control"></div>
             Matricule:
            
                         
                                             
                      <button type="submit"   value="rechercher..." class="btn btn-success">  
                <span class="glyphicon glyphicon-search" >
                    
                </span>
                          
                </button>
               
          
                    </form>           
                               
            
          
        
        
        </div>
    
    </div>
        <div class="panel panel-primary " >
        <div class="panel-heading">  Liste de notification </div>
        <div class="panel-body">
            <table class="table table-striped table-bordered">
            <thead>
           <tr>
          
             <th>Matricule</th> 
               <th>date_notification</th> 
                  <th>type_congee</th> 
                    <th>Action</th> 
                </tr>     
                
                
                </thead>
            <tbody>
                
                
                <?php while($notification=$resultatC->fetch()){
    
 ?>
             
                <tr>
  
             
       <td> <?php echo $notification['matricule'] ?>
                </td>
        <td> <?php echo $notification['date_notification'] ?>
             <td> <?php echo $notification['type_congee'] ?>
                 
                </td>
       
                
       
               
       
                
      
               
                     <td>
               
                
                             
                        <a onclick="return confirm('etre vous sur de vouloir supprimer le notification ')" href= " ../../backend/codes/supprimernotif.php?id_notification=<?php echo $notification['id_notification'] ?>"> <span class="glyphicon glyphicon-trash" ></a>
                             <a href="imprimernotification.php " > <span class="glyphicon glyphicon-print" > 
                </span>
                     
               
                </td> 
                </tr>
        <?php } ?>
           
                </tbody>
            
            
            </table>
        
        
        </div>
    
    </div>

    </div>
    </body>
</HTML>