
<nav class="navbar navbar-inverse navbar-fixed-top">
    <div class= container-fluid">
     <div class ="navbar-header" > 
       <a href="../../admin/pages/services.php" class="navbar-brand">Gestion de stagiaires </a></div>
<ul class= "nav navbar-nav" >
    <li><a href ="stagiaires.php">les stagières</a></li>
    <li><a href ="felieres.php">les felières</a> </li>
    <li><a href="utilisateurs.php"> les utilisateurs</a></li>
</ul>
</div>
</nav>
