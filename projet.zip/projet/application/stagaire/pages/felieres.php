<?php 
require_once("connexiondb.php");

/*
if(isset($_GET['nomF']))
    
  $nomf=$_GET['nomF'];
else
    $nomf="";
    */


$nomf=isset($_GET['nomF'])?$_GET['nomF']:"";
$niveau = isset($_GET['niveau'])?$_GET['niveau']:"all";

if ($niveau=="all"){
$requete="select * from filiere where nomfiliere like '%$nomf%'";
   
}else{
    $requete ="select * from filiere
    where nomfiliere like '%$nomf%' and niveau='$niveau'";
}


$resultatF=$pdo->query($requete);
;

?>

<!DOCTYPE HTML>
<html>
    <head>
        <meta charest="utf-a">
        <tit>Gestion des felières </tit>
        <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
    </head>
    <body>
        <?php include("menu.php");?>
        <div class="container">
          <div class="panel panel-success margetop" >
            <div class="panel-heading">Rechercher des filières ... </div>
            <div class ="panel-body">
            <form method="get" action="felieres.php" class="form-inline" >
                <div class ="form-group"></div>
                <input type="text" name="nomF" placeholder=" nom de filière" class="form-control " value"<?php echo $nomf ?>" />
                <label for="niveau">Niveau:</label>
                <select name="niveau"  class="form-control" id="niveau" onchange="this.form.submit()">
                     <option value="all"<?php if($niveau==="all") echo "selected" ?>>Tous les niveaux </option>
                     <option value="1ER"<?php if($niveau==="1ER") echo "selected" ?>>1ER </option>
                     <option value="2EME"<?php if($niveau==="2EME") echo "selected" ?>>2EME </option>
                     <option value="M"<?php if($niveau==="M" )echo "selected" ?>>Master </option>
                    <option value="N"<?php if($niveau==="N") echo "selected" ?>>Ingenieure </option>
                </select>
                <button type ="submit" class="btn-success"><span class ="glyphicon glyphicon-search"></span>Rechercher..</button> 
                &nbsp &nbsp;
                <a href="nouvellefiliere.php"><span class ="glyphicon glyphicon-plus"></span>Nouvelle filière</a>
                </form>
            </div>
           
        </div>
          <div class="panel panel-primary" >
            <div class="panel-heading">Liste des filières</div>
            <div class ="panel-body">
              <table class="table table-striped table-bordred">
                <thead>
                    <tr>
                    <th>Id_filiere </th><th>Nom filiere</th><th>Niveau </th>
                        <th>Actions </th>
                        
                    </tr>
                  
                  </thead>
                  <tbody>
                      
                      <?php while($filiere=$resultatF->fetch()){ ?>
                      <tr> 
                           <td><?php echo $filiere['id_filiere']?></td>
                           <td><?php echo $filiere['nomfiliere']?></td>
                           <td><?php echo $filiere['niveau']?>
                          <td><a href="editerfiliere.php ?idF =<?php echo $filiere['id_filiere']?>"><span class ="glyphicon glyphicon-edit"></span></a>
                           &nbsp;  
                              <a onclick="return confirm('etes vous sur de vouloir supprimer la filière')"
                               href ="supprimerfiliere.php?idF =<?php echo $filiere['id_filiere']?>">
                          <span class ="glyphicon glyphicon-trash"></span></a></td>
                     </tr>
                          <?php } ?>
                          
                            
                      
                  
                  </tbody>
                
                </table>
            </div>
           
        </div>    
        </div>
    </body>
</html>
