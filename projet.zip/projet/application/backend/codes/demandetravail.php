<?php
header("Access-Control-Allow-Origin: *");
include_once('../includes/connexion.php');
//print_r(($_POST));
if(isset($_POST["matricule"]) && isset($_POST["cause"])){

    $matricule=$_POST["matricule"];
   
    $cause=$_POST["cause"];
 
    
$requete="INSERT INTO  travail (matricule,cause)VALUES ('".$matricule."','".$cause."')";
    
if( $con->query ( $requete)>0){
    $rep[0]=1;
    
     //   $row=$res->fetch_assoc();
      //  $rep[1]=$row['id'];
    }else {
        $rep[0]=$con->error;
    }
    echo json_encode($rep);

   header('location:../../solution/message.php'); 

}
?>