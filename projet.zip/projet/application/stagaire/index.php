<?php
    header ("location:pages/felieres.php")
    ?>