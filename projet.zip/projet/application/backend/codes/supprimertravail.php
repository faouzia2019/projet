<?php
header("Access-Control-Allow-Origin: *");
include_once('../includes/connexion.php');
//print_r(($_POST));

if(isset($_GET["id_travail"])) {
    $id=$_GET["id_travail"];
   

    $res = $con->query("SELECT id_travail from travail where id_travail=$id ");
    if($res->num_rows>0){
$requete="delete from travail where id_travail=$id ";

       if( $con->query ( $requete)>0){
    $rep[0]=1;
    
     //   $row=$res->fetch_assoc();
      //  $rep[1]=$row['id'];
    }else {
        $rep[0]=$con->error;
    }}
    else {
    $rep[0]=$con->error; }
    echo json_encode($rep);

   

}
                       
?>