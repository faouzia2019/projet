<?php

try
{
    $pdo=new PDO("mysql:host=localhost;dbname=workflowisim","root","");
}
catch(Exception $e)
{
    die('erreur de connecxion:'.$e->getMessage());
}
?>