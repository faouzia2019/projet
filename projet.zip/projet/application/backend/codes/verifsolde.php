<?php
session_start();
header("Access-Control-Allow-Origin: *");
include_once('../includes/connexion.php');
$mysqli=$con;
if(isset($_POST["date_debut"])  && isset($_POST["date_fin"])&& isset( $_POST['type_congee']) &&  isset($_SESSION['matricule']))
{
    $type_congee=$_POST['type_congee'];
    $date_debut=$_POST['date_debut'];
 $date_fin=$_POST['date_fin'];
print_r($_POST);
$duree=dureeconj($date_debut,$date_fin);
echo $duree;
//$anne=recuperer("annee","solde"," where matricule ='$matricule' and typeconges=$type_congee  and solde_restante>0 order by annee asc",$con);
$solde_restante=recuperer("sum(solde_restante)","solde","where  matricule='".$_SESSION['matricule']."' and typeconges=$type_congee   ",$mysqli);
if(count($solde_restante)>0){
   echo $solde_restante[0];
    if($solde_restante[0]>=$duree){
        $res[0]=1;
    }else {
        $res[0]=0;
    }
}else {
    $res[0]=-1;
}

}else {
    $res[0]=-2;
} 

ob_clean();
echo $res[0];
?>