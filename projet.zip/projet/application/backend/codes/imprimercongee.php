<?php

    // Affichage sur n colonnes
    // Permet de réaliser l'affichage du résultat
    // d'une requête dans un tableau sur n colonnes

    $db_server = "localhost"; // Adresse du serveur MySQL
    $db_name = "workflowisim";            // Nom de la base de données
    $db_user_login = "root";  // Nom de l'utilisateur
    $db_user_pass = "";       // Mot de passe de l'utilisateur

    // Ouvre une connexion au serveur MySQL
    $conn = mysqli_connect($db_server,$db_user_login, $db_user_pass, $db_name);

    $req = "SELECT * FROM congee";
     
    //--- Résultat ---//
    $res = mysqli_query($conn,$req);
    //met les données dans un tableau
    while($data = mysqli_fetch_array($res))
    {
    $tablo[]=$data;
    }
    //détermine le nombre de colonnes
    $nbcol=1;

    echo '<table>';
    $nb=count($tablo);
    for($i=0;$i<$nb;$i++){
     
    //les valeurs à afficher
    $valeur1=$tablo[$i]['id_congee'];
    $valeur2=$tablo[$i]['date_debut'];

    if($i%$nbcol==0)
    echo '<tr>';
    echo '<td>',$valeur1,'<br/>',$valeur2,'</td>';

    if($i%$nbcol==($nbcol-1))
    echo '</tr>';

    }
    echo '</table>';
?>
<body>
<p> matricule::::::: <?php echo '<td>',$valeur1,'</td>'?></p>
    <p>date_debut:::::::<?php echo '<td>',$valeur2,'</td>'?></p>

</body>





