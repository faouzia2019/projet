<?php
session_start();
header("Access-Control-Allow-Origin: *");
include_once('../includes/connexion.php');
$mysqli=$con;

//print_r(($_POST));
if(isset($_POST["matricule"]) && isset($_POST["date_debut"])  && isset($_POST["date_fin"])  && isset($_POST["nombre_jours"])  && isset($_POST["type_congee"])){

    $matricule=$_POST['matricule'];
   
    $date_debut=$_POST['date_debut'];
    $date_fin=$_POST['date_fin'];
    $nombre_jours=$_POST['nombre_jours'];
    $type_congee=$_POST['type_congee']; 
    $justif=$_POST['justif'];
    $raison=$_POST['raison'];
if (true){
  $duree=dureeconj($date_debut,$date_fin);

$anne=recuperer("annee","solde"," where matricule ='$matricule' and typeconges=$type_congee  and solde_restante>0 order by annee asc",$con);
$solde_restante=recuperer("solde_restante","solde","where  matricule=$matricule and typeconges=$type_congee and solde_restante>0 order by annee asc",$mysqli);
if(count( $solde_restante)>0){
  //echo $duree;

  //echo $solde_restante[0];
  for($i=0;$i<count($solde_restante);$i++){
    $diff[$i]=$duree-$solde_restante[$i];
    if ($diff[$i]<0){
      echo 'duree';
      $annee=$anne[$i];
      $req= "insert into congee values(
        default,
        '$matricule',
        '$date_debut',
        '$date_fin',
        '$annee',
        '$type_congee',0,
        '$nombre_jours',
        '$raison',
        '$justif',
        '$duree'
        
        )";
        if ($con->query ($req)>0){
          $id_congee=recuperer("max(id_congee)","congee","where matricule ='$matricule'",$con);
          $req="insert into archiv_conge values(
            default,
        '$matricule',
        '$date_debut',
        '$date_fin',
        '$annee',
        '$type_congee',0,
        '$nombre_jours',
        '$raison',
        '$justif',
        '$duree'
          )";
          if ($con->query($req)>0){
            $req="update solde set 
            solde_restante=solde_restante-$duree where matricule=$matricule and typeconges=$type_congee and annee=$annee";
            if(
              $con->query($req)){
                $res[0]=1;
                $iduser=$_SESSION['matricule'];
                $id_congee=recuperer("max(id_congee)","congee","where matricule ='$matricule'",$con);
                $req="insert into operations values(
                  default,
                  '$iduser','$id_congee[0]',
                  'ajout_conge',default 
                  )";
                  if ($con->query($req)>0){
                    $res[0]=1; 

        }else{ echo $con->error;
        $res[0]=0; }
        }else{
          echo $con->error;
          $res[0]=0;
        }
        
    } else{
      echo $con->error;
      $res[0]=0;
    }$duree=$diff[$i];
  }
}




/*
if( $con->query ( $requete)>0){
    $rep[0]=1;
    
     //   $row=$res->fetch_assoc();
      //  $rep[1]=$row['id'];
    }else {
        $rep[0]=$con->error;
    }*/
    
    //echo json_encode($rep);

 // header('location:../../solution/conge.php'); 
  }
}
else {
  echo "No1";
}}
else {
  echo "No2";
}}
?>