<?php 
session_start();
if(isset($_SESSION['nom'])  && isset($_SESSION['prenom'])){




include('menu.php') ;



?>
<div class="col">
<div class="card border-primary mb-3" style="max-width: 40rem;"  >
  <div class="card-header"><H5>Demande de Congee</H5></div>
  <div class="card-body " align="left">
    
   
   
  

               <!-- Or let Bootstrap automatically handle the layout -->
    <div class="col">
      <div class="col-sm" > <form id="submit" action="../backend/codes/demandeconge.php" class="formadd" method="POST"  > 
                    
                    
                    <label class="col-md-4"><b>  Matricule</b></label>
                    <input  class="col-md-8 form-control" type="text" <?php if ($_SESSION['role'] !='1'){?>
                    value="<?php echo $_SESSION['matricule']; ?>" readonly 
                    
                    <?php } ?> placeholder="matricule " name="matricule" required></p>
    
            
                    <label  class="col-md-4"><b>date_debut</b></label>
                    <input  class="col-md-8 form-control"type="date" placeholder="datedebut" name="date_debut"  onchange="calcul()" id="date_debut" required></p>
                    <label  class="col-md-4"><b>date fin</b></label>
                    <input  class="col-md-8 form-control has-error" type="date" placeholder="datefin" name="date_fin"  onchange="calcul()"  required></p>
                    <label  class="col-md-4"><b>nombre_jours</b></label>
                    <input  class="col-md-8 form-control"type="TEXT" autocomplete="off"  placeholder="nombre_jours" name="nombre_jours"  required></p>
    
     <label  class="col-md-4"><b>Type de congee </b></label>
                
                    <select  class="col-md-8 form-control" name="type_congee"  onchange="calcul()">
                      <?php 
                    $idtypeconge=recuperer("id","typeconge","",$con);
                    if(
                      count($idtypeconge)>0
                    ){
                      for($i=0;$i<count($idtypeconge);$i++){
                        $label=recuperer("label","typeconge","where id=".$idtypeconge[$i],$con);
                        ?>
                        <option  value="<?php echo $idtypeconge[$i];?>"class="col-md-8 form-control"><?php echo $label[0];?></option><?php 
                      }
                    }

                      ?>
                             </select>
                            </p>
                      
                     
                    
                      <label class="col-md-4"><b> justification d'abscence</b></label>
                    <input  class="col-md-8 form-control" type="text" placeholder="justification d'abscence " name="justif" ></p>
                    <label class="col-md-4"><b> raison</b></label>
                    <input  class="col-md-8 form-control" type="text" placeholder="raison " name="raison" ></p>
                    <button type="submit" id='submit' class="btn btn-primary "  >Envoyer</button>
                </form></div>
      <div class="col-sm" >
      
      </div>
      
    
    </div>

              

               
        
       </div>
       <script>
        $('input[name=nombre_jours]').keypress(function (evt) {
    evt.preventDefault();
});
      function mefDate(laDate)
      {
        elements = laDate.split('-');
 console.log ((elements));
        return Date.UTC(elements[0].substr(-2,elements[0].length), elements[1] - 1, elements[2]);

      }
 
      function calcul()
      {  if($('#date_debut').val() && $('input[name=date_fin]').val())
        {var dateDeb = mefDate($('#date_debut').val());
        var dateFin = mefDate($('input[name=date_fin]').val());
        if(dateDeb<= dateFin)
        {
          var dif = (dateFin -dateDeb) / 86400000;
       // document.getElementById('ecart').innerHTML = '<b>Il y a ' + dif + ' jour(s) d\'écart.</b>';
       $('input[name=nombre_jours]').val(dif+1) ;
       $.ajax({
    url: "../backend/codes/verifsolde.php",
    type: "post",
    data:"type_congee="+ $('select[name=type_congee]').val()+"&date_debut="+ $('input[name=date_debut]').val()+"&date_fin="+ $('input[name=date_fin]').val(),
    datatype:"json",
    success:function(data){if(data<1){  $('input[name=nombre_jours]').val('');
    alert("votre Solde est insuffisant !")
          $('input[name=nombre_jours]').addClass('has-error');
}}
    
   
}); 
        return false;
        }else{
          $('input[name=nombre_jours]').val('');
          $('input[name=nombre_jours]').addClass('has-error');
} }else{

        }
      }
    </script>

       
        </div>
</body>
</html>
<?php 
   } else{
     header('location:./Login/index.html');
   }  
    ?>

