<?php
   $host = "localhost";
   $username  = "root";
   $passwd = "";
   $dbname = "workflowisim";

   //Creating a connection
   $con =new mysqli ($host, $username, $passwd, $dbname);

   function recuperer($col,$tab,$test,$con)
{
	 $con->query("SET NAMES 'utf8'");
	$query = "SELECT $col from $tab $test";

	//$mysqli->query("SET NAMES 'cp1256' ");
$result = $con->query($query) or die($con->error.__LINE__);
// Affichage des résultats en HTML






		
$rees=array();
$i=0;
while ($line = $result->fetch_assoc()) {
    foreach ($line as $col_value) {
     $rees[$i]=  $col_value;
$i++;
    }
}
return $rees;
}



function calculmois($DateDébut,$DateFin){
  $datetime1 = new DateTime($DateDébut);
    $datetime2 = new DateTime($DateFin);
    $interval = $datetime1->diff($datetime2);
  return   $nbday= $interval->format('%m'); //Retourne le nombre de mois
}


function dureeconj($DateDébut,$DateFin){
  $datetime1 = strtotime($DateDébut);
    $datetime2 = strtotime($DateFin);
    $interval = $datetime2-$datetime1;
  return   $nbday=floor (($interval/(60*60*24))+1); //Retourne le nombre de mois
}

?>