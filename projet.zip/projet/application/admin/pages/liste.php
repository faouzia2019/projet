<?php
require_once("connexiondb.php");

$requete=" select id_liste, matricule,dernier_attestation,cause from  liste " ;
$resultatC=$pdo->query($requete);
//$nomf=$_Get['5'];
?>


<! DOCTYPE HTML>
<html>
<head>
  <meta charset="utf-8">
    <title>liste service</title>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
    </head>
<body> 
    <?php include("menu.php");?>
    <div class="container">
    <div class="panel panel-success  margetop" >
        <div class="panel-heading">  rechercher ...</div>
        <div class="panel-body"> 
            <form method="get" action="" class="form-inline">
                <div class="form-group">
            <input type="text" name="name" placeholder="matricule employer " class="form-control"></div>
             Matricule:
            
                         
                                             
                      <button type="submit"   value="rechercher..." class="btn btn-success">  
                <span class="glyphicon glyphicon-search" >
                    
                </span>
                          
                </button>
               
          
                    </form>           
                               
            
          
        
        
        </div>
    
    </div>
        <div class="panel panel-primary " >
        <div class="panel-heading">  Liste de services  </div>
        <div class="panel-body">
            <table class="table table-striped table-bordered">
            <thead>
           <tr>
          
             <th>Matricule</th> 
               <th>dernier_attestation</th> 
                  <th>cause</th> 
                    <th>Action</th> 
                </tr>     
                
                
                </thead>
            <tbody>
                
                
                <?php while($liste=$resultatC->fetch()){
    
 ?>
             
                <tr>
  
             
       <td> <?php echo $liste['matricule'] ?>
                </td>
        <td> <?php echo $liste['dernier_attestation'] ?>
             <td> <?php echo $liste['cause'] ?>
                 
                </td>
       
                
       
               
       
                
      
               
                     <td> <a href="modifierliste.php" ><span class="glyphicon glyphicon-edit" ></a>
               
                
                             
                           
                        <a onclick="return confirm('etre vous sur de vouloir supprimer liste des services ')" href= " ../../backend/codes/supprimerliste.php?id_liste=<?php echo $liste['id_liste'] ?>"> <span class="glyphicon glyphicon-trash" ></a>
                             <a href="imprimerliste.php " > <span class="glyphicon glyphicon-print" > 
                </span>
                             <a href="envoyerliste.php " >  <span class="glyphicon glyphicon-envelope" ></a>
                </span>
               
                </td> 
                </tr>
        <?php } ?>
           
                </tbody>
            
            
            </table>
        
        
        </div>
    
    </div>

    </div>
    </body>
</HTML>