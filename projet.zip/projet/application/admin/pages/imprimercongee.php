<?php
require_once("connexiondb.php");
$id_congee=isset($_GET['id_congee'])?$_GET['id_congee']:0;
$requete="select congee.matricule,congee.date_debut,congee.date_fin,congee.nombre_jours,congee.type_congee,employer.nom,employer.prenom from congee,employer where id_congee=$id_congee and congee.matricule=employer.matricule";

$resultat=$pdo->query($requete);
$congee=$resultat->fetch();
$matricule=$congee['matricule'];
$nom=$congee['nom'];
$prenom=$congee['prenom'];
$date_debut=$congee['date_debut'];
$date_fin=$congee['date_fin'];
$nombre_jours=$congee['nombre_jours'];
$type_congee=$congee['type_congee'];
//$nomf=$_Get['5'];
?>


<! DOCTYPE HTML>
<html>
<head>
  <meta charset="utf-8">
    <title>Imprimer congeer congee</title>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
    </head>
<body> 
   
    <?php include("menu.php");?>
    
    <div class="container">
    <div class="panel panel-success  margetop" >
        <div class="panel-heading" align="center">   Demande de congee </div>
        <div class="panel-body"> 
            <form method="post" action="updatecongee.php" class="form">
               <p align="left">République Tunisienne</p><p>Ministère de l'Enseignement Supérieur </p><p>et de Recherche Scientifique</p><p>Université de Gabès    <img src="../images/flag_tn%20(1).gif"  align="right"/></p><hr>

                <div class="form-group" align="center">
                         <p>     <label for="id_congee">id  de congee:                          <?php echo $id_congee ?> </label>
           
                </p>
                
                <div class="form-group" align="center">
                     <label for="matricule" >matricule  de employer :                              <?php echo $matricule ?></label>
           
                     <div class="form-group" align="center">
                     <label for="nome" >nom  de employer :<?php echo $congee['nom'] ?></label>
                        <div class="form-group" align="center">
                     <label for="prenom" >prenom de employer :<?php echo $congee['prenom'] ?></label>

                          <div class="form-group">
                     <label for="date_debut">date_debut                                               :<?php echo $date_debut ?> </label>
           
                
                 <div class="form-group">
                     <label for="date_fin">date_fin :                                           <?php echo $date_fin ?> </label>
           
                
                 <div class="form-group">
                     <label for="nombre_jours">nombre_jours :                                     <?php echo $nombre_jours ?> </label>
            
            
                <div  class="form-group">
                    <label for="type_congee" >type_congee:                                         <?php echo $type_congee ?></label>
           
                                
                      
                    
                    
                    <hr>
                    <p align="left">Medenine le:/ <p>   <p align=right>            Signature      </p>                                                   
                
                    </div>
                <button type="submit" class="btn-btn-success">
                <span class="glyphicon glyphicon-save"></span> Imprimer </button>
                
                     
            
                            
                   </form>
            
          
            
        
            
      
                 
                </tbody>
            
            
            </table>
        
         <?php
echo '<a href="javascript:window.print()"> <span class="glyphicon glyphicon-save">Imprimer </span></a>';
?>
        </div>
    
    </div>

    </div>
    </body>
</HTML>