<?php
header("Access-Control-Allow-Origin: *");
include_once('../includes/connexion.php');
//print_r(($_POST));

$matricule=$_POST["matricule"];
    $nom=$_POST["nom"];
    $prenom=$_POST["prenom"];
    $adresse=$_POST["adresse"];
    $date_de_naissance=$_POST["date_de_naissance"];
    $telephone=$_POST["tephone"];
    $email=$_POST["email"];
    $grade=$_POST["grade"];
    
$res = $con->query ( "INSERT INTO employer(matricule,nom,prenom,adresse,date_de_naissance,telephone,email,grade)VALUES (".$_POST["matricule"].",".$_POST["nom"].",".$_POST["prenom"].",".$_POST["adresse"].",".$_POST["date_de_naissance"].",".$_POST["telephone"].",".$_POST["email"].",".$_POST["grade"].")");

    
?>