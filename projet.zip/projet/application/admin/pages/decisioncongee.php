<?php
require_once("connexiondb.php");
$id_congee=isset($_GET['id_congee'])?$_GET['id_congee']:0;
$requete="select matricule,date_debut,date_fin,nombre_jours,type_congee,decision from congee where id_congee=$id_congee";

$resultat=$pdo->query($requete);
$congee=$resultat->fetch();
$matricule=$congee['matricule'];
$date_debut=$congee['date_debut'];
$date_fin=$congee['date_fin'];
$nombre_jours=$congee['nombre_jours'];
$type_congee=$congee['type_congee'];
$decision=$congee['decision'];
//$nomf=$_Get['5'];
?>


<! DOCTYPE HTML>
<html>
<head>
  <meta charset="utf-8">
    <title>Editer congee</title>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
    </head>
<body> 
    <?php include("menu.php");?>
    
    <div class="container">
    <div class="panel panel-success  margetop" >
        <div class="panel-heading">  Decision de demande de congee</div>
        <div class="panel-body"> 
            <form method="post" action="updatecongee.php" class="form">
               
                <div class="form-group">
                    <label for="id_congee">id  de congee :<?php echo $id_congee ?> </label>
            <input type="hidden" name="id_congee"  class="form-control"  value="<?php echo $id_congee ?>"/></div>
                
                
                <div class="form-group">
                     <label for="matricule">matricule  de employer :<?php echo $matricule ?> </label>
            <input type="hidden" name="matricule" placeholder="matricule" class="form-control" value="<?php echo $matricule ?>"/></div>
                
                <div class="form-group">
                     <label for="date_debut">date_debut :<?php echo $date_debut ?> </label>
            <input type="hidden" name="date_debut" placeholder="date_debut" class="form-control" value="<?php echo $date_debut ?>"/></div>
                
                 <div class="form-group">
                     <label for="date_fin">date_fin :<?php echo $date_fin ?> </label>
            <input type="hidden" name="date_fin" placeholder="date_fin" class="form-control" value="<?php echo $date_fin ?>"/></div>
                
                 <div class="form-group">
                     <label for="nombre_jours">nombre_jours :<?php echo $nombre_jours ?> </label>
            <input type="hidden" name="nombre_jours" placeholder="nombre_jours" class="form-control" value="<?php echo $nombre_jours ?>"/></div>
            
                <div  class="form-group">
                    <label for="type_congee" >type_congee:<?php echo $type_congee ?></label>
            <select type="hidden"  name="type_congee" class="form-control" id="type_congee" >
              
                <option value="maturnité"  type="hidden" <?php if($type_congee=="maturnité") echo "selected" ?>>  maturnité  </option>
                 
               <option value="annuelle"  type="hidden" <?php if($type_congee=="annuelle") echo "selected" ?>> annuelle  </option> 
                
                <option value="maladie" type="hidden" <?php if($type_congee=="maladie") echo "selected" ?>>  maladie </option>
                
                         
                 </select>  
                    
                      <div  class="form-group">
                    <label for="decision" >decision</label>
            <select name="decision" class="form-control" id="decision" >

            

              
                <option value="accepter" <?php if($type_congee=="accepter") echo "selected" ?>>  accepter  </option>
                 
               <option value="refuser" <?php if($type_congee=="refuser") echo "selected" ?>> refuser  </option> 
                
                
            
                         
                 </select>  
                    
                    
                    </div>

                    <div class="form-group">
  <label for="commentaire">Votre commentaire</label>
  <textarea class="form-control rounded-0" id="commentaire" rows="3"></textarea>
</div>

                <button type="submit" class="btn-btn-success">
                <span class="glyphicon glyphicon-Edit"></span> Envoyer </button>
                
                     
            
                            
                   </form>
            
          
        
        
        
              
      
                 
                </tbody>
            
            
            </table>
        
        
        </div>
    
    </div>

    </div>
    </body>
</HTML>