<?php
$message=isset($_GET['message'])?isset($_GET['message'])?:"Erreur";
?>



<!DOCTYPE HTML>
<html>
    <head>
        <meta charest="utf-a">
        <tit>Alerte </tit>
        <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
         <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
    </head>
    <body>
        <?php include("menu.php");?>
          <div class="container">
          <div class="panel panel-danger  margetop" >
            <div class="panel-heading">Rechercher des filières ... </div>
            <div class ="panel-body">
               <h3><?php echo $message ?></h3>
            <a href ="<?php echo $_SERVER['HTTP_REFERER'] ?>">retour </a>
            </div>
           
        </div>
          </div> 
    </body>
</html>
