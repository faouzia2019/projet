<?php
require_once("connexiondb.php");

$requete=" select  congee.id_congee,congee.date_debut,congee.date_fin,congee.matricule,congee.nombre_jours, congee.type_congee, congee.decision,employer.nom,employer.prenom from congee, employer where congee.matricule=employer.matricule " ;
$resultatC=$pdo->query($requete);
//$nomf=$_Get['5'];
?>


<! DOCTYPE HTML>
<html>
<head>
  <meta charset="utf-8">
    <title>gestion congee</title>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
    </head>
<body> 
    <?php include("menu.php");?>
    
    <div class="container">
    <div class="panel panel-success  margetop" >
        <div class="panel-heading">  rechercher ...</div>
        <div class="panel-body"> 
            <form method="get" action="congee.php" class="form-inline">
                <div class="form-group">
            <input type="text" name="name" placeholder="tapez le type de congee" class="form-control"></div>
                Type:
            <select name="type" class="form-control" id="type" >
              <option value="all"> tous type de congee  </option>
                <option value="ma">  maturnité  </option>
                 
               <option value="an"> annuelle  </option> 
                
                <option value="m">  maladie </option>
                
                         
                 </select>  
                
                      <button type="submit"   value="rechercher..." class="btn btn-success">  
                <span class="glyphicon glyphicon-search" >
                </span>
                 
                </button>
            
            
                            
                   </form>
            
          
        
        
        </div>
    
    </div>
        <div class="panel panel-primary " >
        <div class="panel-heading">  Liste de congeé</div>
        <div class="panel-body">
            <table class="table table-striped table-bordered">
            <thead>
           <tr>
           
             <th>Matricule</th> 
               <th>Date_debut</th> 
               <th>Date_fin</th>   
             <th>Type_congee</th> 
               <th>Nombre_jours</th>
                 <th>Decision</th>
                
                 <th>nom</th>
                 <th>prenom</th>
                 <th>Action</th>
                </tr>     
                
                
                </thead>
            <tbody>
                
                <?php while($congee=$resultatC->fetch()){
    
 ?>
             
                <tr>
  
             
       <td> <?php echo $congee['matricule'] ?>
                </td>
        <td> <?php echo $congee['date_debut'] ?>
                </td>
       <td> <?php echo $congee['date_fin'] ?>
                </td>
       <td> <?php echo $congee['type_congee'] ?> </td>
               
       <td> <?php echo $congee['nombre_jours'] ?>
                </td>
      
                 <td> <?php echo $congee['decision'] ?>
                </td>
                <td> <?php echo $congee['nom'] ?>
                </td>
                <td> <?php echo $congee['prenom'] ?>
                </td>
                     <td> <a href="decisioncongee.php?id_congee=<?php echo $congee['id_congee'] ?>"><span class="glyphicon glyphicon-edit" ></a>
               
                
                        <a onclick="return confirm('etre vous sur de vouloir supprimer le congeé ')" href= " ../../backend/codes/supprimercongee.php?id_congee=<?php echo $congee['id_congee'] ?>"> <span class="glyphicon glyphicon-trash" ></a>
                            
              <a href="imprimercongee.php?id_congee=<?php echo $congee['id_congee'] ?>"><span class="glyphicon glyphicon-print" ></a>
               
                  
                             <a href="envoyercongee.php " >  <span class="glyphicon glyphicon-envelope" ></a>
                </span>
                   
                </td> 
                </tr>
        <?php } ?>
           
                </tbody>
            
            
            </table>
        
        
        </div>
    
    </div>

    </div>
    </body>
</HTML>