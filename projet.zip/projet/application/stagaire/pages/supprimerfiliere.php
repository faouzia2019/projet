<?php 
require_once("connexiondb.php");
$idf=isset($_GET['idF'])?$_GET['idF']:0;

$requete="delete from filiere where id_filiere=?";
$params=array($idf);
$resultat=$pdo->prepare($requete);
$resultat ->execute($params);
    header ('location:felieres.php');

    
    
    
    
    

?>