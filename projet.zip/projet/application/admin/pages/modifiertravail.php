<! DOCTYPE HTML>
<html>
<head>
  <meta charset="utf-8">
    <title>Modifier attestation travail</title>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
    </head>
<body> 
    <?php include("menu.php");?>
    <div class="container">
                <div class="panel panel-primary  margetop " >
           
                <div class="panel-heading">Modifier les donneés d'attestation travail</div>
        <div class="panel-body"> 
            <form method="POST" action="" class="form">
                
                <div class="form-group">
                    <label for="nom">Matricule de l'employer:</label>
            <input type="number" name="matricule" placeholder="matricule de l'employer " class="form-control"/></div>
                <div class="form-group">
           <label for="nom">Cause  </label>
            <input type="text" name="nom" placeholder="nom de l'employer " class="form-control"/></div>
          
              
          
                           <div class="form-group">               
                      <button type="submit"   value="Modifier" class="btn btn-success">  
                <span class="glyphicon glyphicon-save" >
                </span> Modifier </button></div></form>
    </div>

    </body>


</html>