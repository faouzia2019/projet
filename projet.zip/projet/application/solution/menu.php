
 
<?php

header("Access-Control-Allow-Origin: *");

 include_once('../backend/includes/connexion.php');
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Bootstrap 4 Navbar Color Schemes</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<style>
    .bs-example{
        margin: 20px;
    }
    .navbar{
        margin-bottom: 1rem;
    }
</style>
</head>
<body>
<div class="bs-example">
    <nav class="navbar navbar-expand-lg navbar navbar-dark bg-primary">
        <a href="../solution/exemple/index.html" class="navbar-brand">ISIMEDENINE</a>
        <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse1">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarCollapse1">
            <div class="navbar-nav">
                <a href="" class="nav-item nav-link active">Service Personnel</a>
                <a href="salaire.php" class="nav-item nav-link active">Attestation salaire</a>
                <a href="travail.php" class="nav-item nav-link active">Attestation travail</a>
                <a href="liste.php" class="nav-item nav-link active">Liste Service</a>
                <a href="allocation.php" class="nav-item nav-link active">Allocation Familliale</a>
                <a href="conge.php" class="nav-item nav-link active">Congee</a>
                <a href="notif.php" class="nav-item nav-link active">Notification</a>
               
                
            </div>
            
            <form class="form-inline ml-auto" action="login/index.html">

                
                <button type="submit" class="btn btn-outline-light" ><?php echo $_SESSION['nom'] ; ?> <?php echo $_SESSION['prenom'] ; ?></button>
                <button type="submit" class="btn btn-outline-light" >Deconnecter 
            </form>
        </div>
    </nav>
	
    

       
  
    <a href="Login/index.html">
          <span class="glyphicon glyphicon-user"></span>
        </a>
  </div>
</nav>
    
<hr>



  </body>
</div>
