<?php
require_once("connexiondb.php");
$id_congee=isset($_POST['id_congee'])?$_POST['id_congee']:0;
$matricule=isset($_POST['matricule'])?$_POST['matricule']:"";
$matricule=isset($_POST['nom'])?$_POST['nom']:"";
$matricule=isset($_POST['prenom'])?$_POST['prenom']:"";
$date_debut=isset($_POST['date_debut'])?$_POST['date_debut']:"";
$date_fin=isset($_POST['date_fin'])?$_POST['date_fin']:"";
$nombre_jours=isset($_POST['nombre_jours'])?$_POST['nombre_jours']:"";
$type_congee=isset($_POST['type_congee'])?$_POST['type_congee']:"";
$decision=isset($_POST['decision'])?$_POST['decision']:"";
$requete="update congee set matricule=? , date_debut=? , date_fin=? , nombre_jours=? , type_congee=?,decision=? where id_congee=?";
$params=array($matricule,$date_debut,$date_fin,$nombre_jours,$type_congee,$decision,$id_congee);
$resultat=$pdo->prepare($requete);
$resultat->execute($params);
header('location:congee.php');
?>