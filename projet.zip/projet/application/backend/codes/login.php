<?php
session_start();
header("Access-Control-Allow-Origin: *");
include_once('../includes/connexion.php');
//print_r(($_POST));

if(isset($_POST["email"]) && isset($_POST["pass"])){
    $email=$_POST["email"];
    $pass=$_POST["pass"];

    $res = $con->query("SELECT role,  matricule FROM utilisateur where login='$email' and pass='$pass'");
    if($res->num_rows>0){
      
?>
<?php 
 

        $rep[0]=1;

        $row=$res->fetch_assoc(); 
        // print_r ($row);

        $rowmatricule = $row['matricule'];
        $rowrole = $row['role'];
        $_SESSION['matricule'] =$rowmatricule;
        $_SESSION['role'] =$rowrole;
        $respersonne = $con->query("SELECT nom , prenom FROM employer  where matricule= '".$rowmatricule."' ");
        if($respersonne->num_rows>0){
            $rowpersonne=$respersonne->fetch_assoc();
            $_SESSION['nom'] = $rowpersonne['nom'];
            $_SESSION['prenom'] = $rowpersonne['prenom'];
            $rowmatricule = $row['matricule'];
            

            }
      if($row['role']== '1')
         {
        //  echo $row['role'];
          $url="../../admin/pages/services.php";
       header('location: '.$url);
//exit;
    }
        else {
     //!! 
  //   header('../services.php');
           //   echo $row['role'];
              $url="../../solution/notif.php";
                  header('location: '.$url);
//exit;
    }
 //   echo json_encode($rep);
}}
?>