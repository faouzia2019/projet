<?php
header("Access-Control-Allow-Origin: *");
include_once('../includes/connexion.php');
//print_r(($_POST));
if(isset($_POST["matricule"]) && isset($_POST["nom_conjoint"])  && isset($_POST["profession_conjoint"])  && isset($_POST["nombre_fils"])  && isset($_POST["nom_fils"]) && isset($_POST["fils_bourse"]) && isset($_POST["situation_familliale"])){

    $matricule=$_POST["matricule"];
   $nom_conjoint=$_POST["nom_conjoint"];
    $profession_conjoint=$_POST["profession_conjoint"];
    $nombre_fils=$_POST["nombre_fils"];
     $nom_fils=$_POST["nom_fils"];
    $fils_bourse=$_POST["fils_bourse"];
    $situation_familliale=$_POST["situation_familliale"];
 
    
$requete="INSERT INTO  allocation (matricule,nom_conjoint,profession_conjoint,nombre_fils,nom_fils,fils_bourse,situation_familliale)
VALUES ('".$matricule."','".$nom_conjoint."','".$profession_conjoint."',".$nombre_fils.",'".$nom_fils."',
'".$fils_bourse."','".$situation_familliale."')";  
    
if( $con->query ( $requete)>0){
    $rep[0]=1;
    
     //   $row=$res->fetch_assoc();
      //  $rep[1]=$row['id'];
    }else {
        $rep[0]=$con->error;
    }
    echo json_encode($rep);

   header('location:../../solution/message.php'); 

}
?>