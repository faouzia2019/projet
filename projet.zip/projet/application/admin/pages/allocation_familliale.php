<?php
require_once("connexiondb.php");

$requete=" select id_allocation,matricule,nom_conjoint,profession_conjoint,nom_fils,nombre_fils,fils_bourse,situation_familliale from  allocation  " ; 
$resultatC=$pdo->query($requete);
//$nomf=$_Get['5'];
?>


<! DOCTYPE HTML>
<html>
<head>
  <meta charset="utf-8">
    <title>allocation familliale</title>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
    </head>
<body> 
    <?php include("menu.php");?>
    <div class="container">
    <div class="panel panel-success  margetop" >
        <div class="panel-heading">  rechercher ...</div>
        <div class="panel-body"> 
            <form method="get" action="" class="form-inline">
                <div class="form-group">
            <input type="text" name="name" placeholder="matricule employer " class="form-control"></div>
             Matricule:
            
                         
                                             
                      <button type="submit"   value="rechercher..." class="btn btn-success">  
                <span class="glyphicon glyphicon-search" >
                </span></button>
               
          
                    </form>           
                               
            
          
        
        
        </div>
    
    </div>
        <div class="panel panel-primary " >
        <div class="panel-heading">  Liste d'allocation familliale  </div>
        <div class="panel-body">
            <table class="table table-striped table-bordered">
            <thead>
           <tr>
          
             <th>Matricule</th> 
               <th>nom_conjoint</th> 
                  <th>profession_conjoint</th> 
                <th>nombre_fils</th> 
               <th>fils_bourse</th> 
                  <th>nom_fils</th> 
               
                 <th>situation_familliale</th> 
                    <th>Action</th> 
                </tr>     
                
                
                </thead>
            <tbody>
                
                
                <?php while($allocation =$resultatC->fetch()){
    
 ?>
             
                <tr>
  
             
       <td> <?php echo $allocation ['matricule'] ?>
                </td>
        <td> <?php echo $allocation ['nom_conjoint'] ?>
             <td> <?php echo $allocation['profession_conjoint'] ?>
                 
                 
                </td>
       
                <td> <?php echo $allocation['nombre_fils'] ?> </td>
       
               
                <td> <?php echo $allocation['fils_bourse'] ?> </td>
                    
                <td> <?php echo $allocation['nom_fils'] ?> </td>
                    
                <td> <?php echo $allocation['situation_familliale'] ?> </td>
       
                
      
               
                     <td> <a href="editerallocation.php " ><span class="glyphicon glyphicon-edit" ></a>
               
                
                         <a onclick="return confirm('etre vous sur de vouloir supprimer allocation ')" href= " ../../backend/codes/supprimerallocation.php?id_allocation=<?php echo $allocation['id_allocation'] ?>"> <span class="glyphicon glyphicon-trash" ></a>
 
                <a href="imprimerallocation.php " > <span class="glyphicon glyphicon-print" > 
                </span>
                             <a href="envoyerallocation.php " >  <span class="glyphicon glyphicon-envelope" ></a>
                </span>
                </td> 
                </tr>
        <?php } ?>
           
                </tbody>
            
            
            </table>
        
        
        </div>
    
    </div>

    </div>
    </body>
</HTML>