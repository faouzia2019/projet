<!DOCTYPE HTML>
<html>
    <head>
        <meta charest="utf-a">
        <tit>Page Blanche </tit>
        <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
         <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
    </head>
    <body>
        <?php include("menu.php");?>
          <div class="container">
          <div class="panel panel-success margetop" >
            <div class="panel-heading">Rechercher des filières ... </div>
            <div class ="panel-body">
                le contenu de paneau
            </div>
           
        </div>
          <div class="panel panel-primary" >
            <div class="panel-heading">Liste des filières </div>
            <div class ="panel-body">
              le tableau des filières
            </div>
           
        </div>    
        </div>
    </body>
</html>
