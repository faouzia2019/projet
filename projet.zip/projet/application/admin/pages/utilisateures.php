<! DOCTYPE HTML>
<html>
<head>
  <meta charset="utf-8">
    <title>page blanche</title>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
    </head>
<body> 
    <?php include("menu.php");?>
    <div class="container">
    <div class="panel panel-success  margetop" >
        <div class="panel-heading">  rechercher ...</div>
        <div class="panel-body"> le contenu de panneau
        
        
        </div>
    
    </div>
        <div class="panel panel-primary " >
        <div class="panel-heading">  Liste des utilisateures</div>
        <div class="panel-body"> les tableaus des utilisateures 
        
        
        </div>
    
    </div>

    </div>

    </body>


</html>