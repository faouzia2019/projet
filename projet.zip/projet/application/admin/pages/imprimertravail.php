<?php
require_once("connexiondb.php");
$id_travail=isset($_GET['id_travail'])?$_GET['id_travail']:0;
$requete="select travail.matricule,travail.cause,employer.nom,employer.prenom from travail,employer where id_travail=$id_travail and travail.matricule=employer.matricule";

$resultat=$pdo->query($requete);
$travail=$resultat->fetch();
$matricule=$travail['matricule'];
$cause=$travail['cause'];
$nom=$travail['nom'];
$prenom=$travail['prenom'];

?>


<! DOCTYPE HTML>
<html>
<head>
  <meta charset="utf-8">
    <title>Imprimer congeer congee</title>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
    </head>
<body> 
   
    <?php include("menu.php");?>
    
    <div class="container">
    <div class="panel panel-success  margetop" >
        <div class="panel-heading" align="center">   Demande d'attestation de travail </div>
        <div class="panel-body"> 
            <form method="post" action="updatetravail.php" class="form">
               <p align="left">République Tunisienne</p><p>Ministère de l'Enseignement Supérieur </p><p>et de Recherche Scientifique</p><p>Université de Gabès    <img src="../images/flag_tn%20(1).gif"  align="right"/></p><hr>

                
           
                </p>
                
                <div class="form-group" align="center">
                     <label for="matricule" >matricule  de employer :                              <?php echo $matricule ?></label>
           
                     <div class="form-group" align="center">
                     <label for="nome" >nom  de employer :                                          <?php echo $travail['nom'] ?></label>
                        <div class="form-group" align="center">
                     <label for="prenom" >prenom de employer :                                       <?php echo $travail['prenom'] ?></label>

                          <div class="form-group">
                     <label for="date_debut">cause:                                               <?php echo $travail['cause'] ?> </label>
           
                
                 
                
            
                                
                      
                    
                    
                    <hr>
                    <p align="left">Medenine le:/ <p>   <p align=right>            Signature      </p>                                                   
                
                    </div>
                <button type="submit" class="btn-btn-success">
                <span class="glyphicon glyphicon-save"></span> Imprimer </button>
                
                     
            
                            
                   </form>
            
          
            
        
            
      
                 
                </tbody>
            
            
            </table>
        
         <?php
echo '<a href="javascript:window.print()"> <span class="glyphicon glyphicon-save">Imprimer </span></a>';
?>
        </div>
    
    </div>

    </div>
    </body>
</HTML>