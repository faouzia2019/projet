<?php 
session_start();
if(isset($_SESSION['nom'])  && isset($_SESSION['prenom'])){




include('menu.php') ;



?>

<!DOCTYPE html>
<html lang="en">
<div class="col">

<div class="card border-primary mb-3" style="max-width: 40rem;"  >
  <div class="card-header"><H5>Demande d'attestation salaire</H5></div>
  <div class="card-body " align="left">
                <form  id="ajoutsalaire" action="../backend/codes/demandesalaire.php" class="formadd" method="POST">
                    
                    
                    <label class="col-md-4"><b>  Matricule</b></label>
                    <input  class="col-md-8 form-control" type="number" <?php if ($_SESSION['role'] !='1'){?>
                    value="<?php echo $_SESSION['matricule']; ?>" readonly 
                    
                    <?php } ?> placeholder="matricule" name="matricule" required></p>
    
            
                    <label  class="col-md-4"><b>langue</b></label>
                    <input  class="col-md-8 form-control"type="text" placeholder="langage" name="langage" required size="64" maxLength="15" minLength="3"></p>
                    
                    
                    
                <label  class="col-md-4"><b>Mois </b></label>
                
                    <select  class="col-md-8 form-control" name="mois"  type="text">
                        <option class="col-md-8 form-control">Janvier</option>
                         <option class="col-md-8 form-control">fevrier</option>
                         <option class="col-md-8 form-control">Mars</option>
                        
                        <option class="col-md-8 form-control">Avril</option>
                         <option class="col-md-8 form-control">mai</option>
                         <option class="col-md-8 form-control">juin</option>
                        <option class="col-md-8 form-control">juillet</option>
                         <option class="col-md-8 form-control">aout</option>
                         <option class="col-md-8 form-control">septembre</option>
                        <option class="col-md-8 form-control">Octobre</option>
                         <option class="col-md-8 form-control">nouvembre</option>
                         <option class="col-md-8 form-control">decembre</option>

                            </select>

                    
                    
                            </p>
                      
                      <button type="submit" id='submit' class="btn btn-primary ">Envoyer</button>
                    
                </form>
               
               
               
        
     
        
        
    
        </div>
</body>
</html>

<?php 
   } else{
     header('location:./Login/index.html');
   }  
    ?>