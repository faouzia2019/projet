<?php
try{

$pdo=new PDO("mysql:host=localhost;dbname=workflowisim","root","");
}catch(exception $e){
  die ('Erreur de connexion!' .$e->getMessage());
}

?>