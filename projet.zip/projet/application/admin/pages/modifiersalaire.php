<! DOCTYPE HTML>
<html>
<head>
  <meta charset="utf-8">
    <title>Modifier Attestation Salaire</title>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
    </head>
<body> 
    <?php include("menu.php");?>
    <div class="container">
                <div class="panel panel-primary  margetop " >
           
                <div class="panel-heading">Modifier les donneés d'attestation Salaire</div>
        <div class="panel-body"> 
            <form method="POST" action="" class="form">
                
                <div class="form-group">
                    <label for="nom">Matricule de l'employer:</label>
            <input type="number" name="matricule" placeholder="matricule de l'employer " class="form-control"/></div>
                <div class="form-group">
           <label for="nom">Langage  </label>
            <input type="text" name="nom" placeholder="nom de l'employer " class="form-control"/></div>
          <select name="type" class="form-control" id="type"  type="text">
              <option value="all"> janvier  </option>
                <option value="ma"> fevrier  </option>
                 
               <option value="an"> mars  </option> 
                
                <option value="m"> maii </option>
                <option value="all"> juin  </option>
                <option value="ma"> juillet  </option>
                 
               <option value="an"> aout  </option> 
                
                <option value="m"> septembre </option>
              <option value="ma"> octobre </option>
                 
               <option value="an">nouvembre  </option> 
                
                <option value="m"> dicembre </option>
                         
                 </select>  
              
          
                           <div class="form-group">               
                      <button type="submit"   value="Modifier" class="btn btn-success">  
                <span class="glyphicon glyphicon-save" >
                </span> Modifier </button></div></form>
    </div>

    </body>


</html>