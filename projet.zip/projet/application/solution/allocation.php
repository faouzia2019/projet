<?php 
session_start();
if(isset($_SESSION['nom'])  && isset($_SESSION['prenom'])){

  session_destroy();
 
  // Supression des cookies de connexion automatique
  setcookie('nom', '');
  setcookie('prenom', '');
   
  header('Location: ./exemple/index.html?deco=1');




include('menu.php') ;



?>
<!DOCTYPE html>
<html lang="en">

<div class="col">
<div class="card border-primary mb-3" style="max-width: 40rem;"  >
  <div class="card-header"><H5>Demande d'allocation familliale</H5></div>
  <div class="card-body " align="left">
        
                <form  id="ajoutallocation" action="../backend/codes/demandeallocationf.php"class="formadd" method="POST">
                    
                    <table class="table table-striped table-bordered">
                    <label class="col-md-4"><b>  Matricule</b></label>
                    <input  class="col-md-8 form-control" type="number" <?php if ($_SESSION['role'] !='1'){?>
                    value="<?php echo $_SESSION['matricule']; ?>" readonly 
                    
                    <?php } ?> placeholder="matricule" name="matricule" required ></p>
    
                    <label  class="col-md-4"><b>nom_conjoint</b></label>
                    <input  class="col-md-8 form-control" type="text" placeholder="nom_conjoint" name="nom_conjoint" required  size="64" maxLength="15" minLength="3"></p>
                <label  class="col-md-4"><b>profession_conjoint</b></label>
                    <input  class="col-md-8 form-control" type="text" placeholder="profession_conjoint" name="profession_conjoint" required  size="64" maxLength="15" minLength="3"></p>
                    <label  class="col-md-4"><b>Nombre_fils</b></label>
                    <input  class="col-md-8 form-control" type="number" placeholder="nombre_fils" name="nombre_fils" required  size="64" maxLength="15" minLength="3"></p>
                    <label  class="col-md-4"><b>nom_fils</b></label>
                    <input  class="col-md-8 form-control"type="text" placeholder="nom_fils" name="nom_fils" required size="64" maxLength="15" minLength="3"></p>
                   
                    <label  class="col-md-4"><b>fils_bourse</b></label>
                    <input  class="col-md-8 form-control"type="text" placeholder="fils_bourse" name="fils_bourse" required   size="64" maxLength="15" minLength="3"></p>
                    <label  class="col-md-4"><b>situation familiale</b></label>
                    <input  class="col-md-8 form-control"type="text" placeholder="situation_familliale" name="situation_familliale" required  size="64" maxLength="15" minLength="3"></p>
                     
    
                    </p>
                      
                            <button type="submit" id='submit' class="btn btn-primary ">Envoyer</button>
                    
                </form>

      
   
        
        
        
    
        </div>
</body>
</html>
<?php 
   } else{
     header('location:./Login/index.html');
   }  
    ?>