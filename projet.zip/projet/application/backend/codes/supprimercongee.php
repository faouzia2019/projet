<?php
header("Access-Control-Allow-Origin: *");
include_once('../includes/connexion.php');
//print_r(($_POST));

if(isset($_GET["id_congee"])) {
    $id=$_GET["id_congee"];
   

    $res = $con->query("SELECT id_congee from congee where id_congee=$id ");
    if($res->num_rows>0){
$requete="delete from congee where id_congee=$id ";

       if( $con->query ( $requete)>0){
    $rep[0]=1;
    
     //   $row=$res->fetch_assoc();
      //  $rep[1]=$row['id'];
    }else {
        $rep[0]=$con->error;
    }}
    else {
    $rep[0]=$con->error; }
    echo json_encode($rep);

   header('location:../../messagesupprimer.php');

}
                       
?>