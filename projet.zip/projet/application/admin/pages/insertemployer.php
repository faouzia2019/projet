<?php
header("Access-Control-Allow-Origin: *");
require_once("connexiondb.php");
//print_r(($_POST));
if(isset($_POST["matricule"]) && isset($_POST["nom"])  && isset($_POST["prenom"])&& isset($_POST["adresse"])&& isset($_POST["telephone"])&& isset($_POST["date_naissance"])&& isset($_POST["email"])&& isset($_POST["grade"])&& isset($_POST["date_recrutement"])){

    $matricule=$_POST["matricule"];
    $nom=$_POST["nom"];
    $prenom=$_POST["prenom"];
   $adresse=$_POST["adresse"];
     $telephone=$_POST["telephone"];
    $date_naissance=$_POST["date_naissance"];
    $email=$_POST["email"];
     $grade=$_POST["grade"];
     $date_recrutement=$_POST["date_recrutement"];

$requete="INSERT INTO  employer(matricule,nom,prenom,adresse,telephone,date_naissance,email,grade,date_recrutement)VALUES ('".$matricule."','".$nom."','".$prenom."','".$adresse."','.$telephone.','".$date_naissance."','".$email."','".$grade."','".$date_recrutement."')";
    
if( $con->query ( $requete)>0){
    $rep[0]=1;
    
     //   $row=$res->fetch_assoc();
      //  $rep[1]=$row['id'];
    }else {
        $rep[0]=$con->error;
    }
    echo json_encode($rep);

   

}
?>