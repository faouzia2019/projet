<! DOCTYPE HTML>
<html>
<head>
  <meta charset="utf-8">
    <title>gestion congee</title>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
    </head>
<body> 
    <?php include("pageblanche.php");?>
    </body>
    </html>