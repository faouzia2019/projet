<?php 
require_once("connexiondb.php");


$nomprenom=isset($_GET['nomPrenom'])?$_GET['nomPrenom']:"";
$filiere = isset($_GET['filiere'])?$_GET['filiere']:"all";
$requeteFiliere="select * from filiere ";
$requete="select * from stagiaire ";
/*
if ($filiere=="all"){
$requete="select * from filiere where nomfiliere like '%$nomf%'";
   
}else{
    $requete ="select id_stagiaire,nom,prenom,nomfiliere,photo,civilite
    from filiere as f , stagiaire as s
    where f.id_filiere=s.id_filiere
    and (nom like '%$nomprenom%' or prenom like '%$nomprenom%')
    and f.id_filiere=s.id_filiere;
}
*/
$resultatFiliere=$pdo->query($requeteFiliere);

$resultatS=$pdo->query($requete);


?>

<! DOCTYPE HTML>
<HTML>
    <head>
        <meta charset="utf-a">
        <tit> Gestion des stagiaires </tit>
        <link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
        <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
    </head>
    <body>
        <?php include("menu.php");?>
        <div class="container">
          <div class="panel panel-success margetop" >
            <div class="panel-heading">Rechercher des stagiaires ... </div>
            <div class ="panel-body">
            <form method="get" action="stagiaires.php" class="form-inline" >
                <div class ="form-group"></div>
                <input type="text" name="nomPrenom " placeholder=" nom et prenom " class="form-control " value"<?php echo $nomprenom ?>" />
                <label for="filiere">filieres:</label>
                <select name="filiere"  class="form-control" id="filiere" onchange="this.form.submit()">
                    <?php while ($filiere=$resultatFiliere->fetch()){
?>
<option><?php echo $filiere['nomfiliere'] ?></option> <?php }?>
                    
                </select>
                <button type ="submit" class="btn-success"><span class ="glyphicon glyphicon-search"></span>Rechercher..</button> 
                &nbsp &nbsp;
                <a href="nouveaustagiaire.php"><span class ="glyphicon glyphicon-plus"></span>Nouveau stagiaires </a>
                </form>
            </div>
           
        </div>
          <div class="panel panel-primary" >
            <div class="panel-heading">Liste des stagiaires </div>
            <div class ="panel-body">
              <table class="table table-striped table-bordred">
                <thead>
                    <tr>
                    <th>Id_stagiaire </th><th>Nom </th><th>Prenom</th>
                        <th>Filiere </th>
                        <th>Photo </th>
                        <th>Civilite </th>
                        <th>Actions </th>
                    </tr>
                  
                  </thead>
                  <tbody>
                      
                     <?php while($stagiaire=$resultatS->fetch()){ 
                      ?>
                      <tr> 
                           <td><?php echo $stagiaire['id_stagiaire']?></td>
                           <td><?php echo $stagiaire['nom']?></td>
                           <td><?php echo $stagiaire['prenom']?></td>
                            <td><?php echo $stagiaire['id_filiere']?></td>
                             <td><img src ="../images/<?php echo $stagiaire['photo']?>"</td>
                            <td><?php echo $stagiaire['civilite']?></td>
                          
                         
                              
                               <td>
                              <a href="editerstagiaire.php ?idS =<?php echo $stagiaire['id_stagiaire']?>"><span class ="glyphicon glyphicon-edit"></span></a>
                           &nbsp;  
                              <a onclick="return confirm('etes vous sur de vouloir supprimer la stagiaire')"
                               href ="supprimerstagiaire.php?idS =<?php echo $stagiaire['id_stagiaire']?>">
                          <span class ="glyphicon glyphicon-trash"></span></a></td>
                     </tr>
                          <?php } ?>
                          
                            
                      
                  
                  </tbody>
                
                </table>
            </div>
           
        </div>    
        </div>
    </body>
</html>
