

 
<?php 
session_start();
if(isset($_SESSION['nom'])  && isset($_SESSION['prenom'])){




include('menu.php') ;



?>
<div class="col">
<div class="card border-primary mb-3" style="max-width: 40rem;"  >
  <div class="card-header"><H5>Demande de notification</H5></div>
  <div class="card-body " align="left">
                <form  id="ajoutnotification" action="../backend/codes/demandenotif.php" class="formadd" method="POST">
                   
                    
                    <label class="col-md-4"><b>  Matricule </b></label>
                    <input  class="col-md-8 form-control" type="number"  <?php if ($_SESSION['role'] !='1'){?>
                    value="<?php echo $_SESSION['matricule']; ?>" readonly 
                    
                    <?php } ?> placeholder="matricule" name="matricule" required></p>
    
            
                    <label  class="col-md-4"><b>Date_notification </b></label>
                    <input  class="col-md-8 form-control" type="date" placeholder="date_notification" name="date_notification" required></p>
                    
                      
                   
                    <label  class="col-md-4"><b>Type de congee </b></label>
                
                    <select  class="col-md-8 form-control" name="type_congee">
                        <option class="col-md-8 form-control">Matirnité</option>
                         <option class="col-md-8 form-control">Annuelle</option>
                         <option class="col-md-8 form-control">Maladie</option>
                            </select>
                            </p>
                      
                            <button type="submit" id='submit' class="btn btn-primary ">Envoyer</button>                    
                </form>
               
               
               
               
        
      
        
        
    
        </div>
        <script>  
 ///alert();
$.ajax({
    url: "./solde.php",
    type: "post",
    datatype:"html",
    success:function(data){}
    
   
}); 
</script>
</body>
</html>

<?php 
   } else{
     header('location:./Login/index.html');
   }  
    ?>
