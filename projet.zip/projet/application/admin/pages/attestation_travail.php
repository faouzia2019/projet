<?php
require_once("connexiondb.php");

$requete=" select travail.id_travail,travail.matricule,travail.cause,employer.nom,employer.prenom  from  travail,employer where employer.matricule=travail.matricule " ;
$resultatC=$pdo->query($requete);
//$nomf=$_Get['5'];
?>


<! DOCTYPE HTML>
<html>
<head>
  <meta charset="utf-8">
    <title>attestation travailr</title>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
    </head>
<body> 
    <?php include("menu.php");?>
    <div class="container">
    <div class="panel panel-success  margetop" >
        <div class="panel-heading">  rechercher ...</div>
        <div class="panel-body"> 
            <form method="get" action="" class="form-inline">
                <div class="form-group">
            <input type="text" name="name" placeholder="matricule employer " class="form-control"></div>
             Matricule:
            
                         
                                             
                      <button type="submit"   value="rechercher..." class="btn btn-success">  
                <span class="glyphicon glyphicon-search" >
                    
                </span></button>
               
          
                    </form>           
                               
            
          
        
        
        </div>
    
    </div>
        <div class="panel panel-primary " >
        <div class="panel-heading">  Liste d'attestation travail  </div>
        <div class="panel-body">
            <table class="table table-striped table-bordered">
            <thead>
           <tr>
          
             <th>Matricule</th> 
             <th>Prenom</th>
             <th>Nom</th>
               <th>Cause</th> 
               
                    <th>Action</th> 
                </tr>     
                
                
                </thead>
            <tbody>
                
                
                <?php while($travail=$resultatC->fetch()){
    
 ?>
             
                <tr>
  
             
       <td> <?php echo $travail['matricule'] ?>
                </td>
                <td> <?php echo $travail['nom'] ?>
                </td>
                <td> <?php echo $travail['prenom'] ?>
                </td>

        <td> <?php echo $travail['cause'] ?>
                </td>
       
                
       
               
       
                
      
               
                     <td> <a href="modifiertravail.php?id_travail=<?php echo $travail['id_travail'] ?>" " ><span class="glyphicon glyphicon-edit" ></a>
               
                
                         
                        <a onclick="return confirm('etre vous sur de vouloir supprimer le congeé ')" href= " ../../backend/codes/supprimertravail.php?id_travail=<?php echo $travail['id_travail'] ?>"> <span class="glyphicon glyphicon-trash" ></a>
                        <a href="imprimertravail.php?id_travail=<?php echo $travail['id_travail'] ?>"><span class="glyphicon glyphicon-print" ></a> 
                </span>
                             <a href="envoyertravail.php " >  <span class="glyphicon glyphicon-envelope" ></a>
                </span>
                </td> 
                </tr>
        <?php } ?>
           
                </tbody>
            
            
            </table>
        
        
        </div>
    
    </div>

    </div>
    </body>
</HTML>