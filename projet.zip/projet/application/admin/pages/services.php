

<?php



session_start();
if(isset($_SESSION['nom'])  && isset($_SESSION['prenom'])){




  include_once('../../backend/includes/connexion.php');



?>

<head>
  <meta charset="utf-8">
    <title>page blanche</title>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

    </head>
<body> 
  <p> </p> 
    <div class="container">
   
        
        
        </div>
        <a href="../../Login/index.html">
          <span class="glyphicon glyphicon-user" align="right"><?php echo $_SESSION['nom'] ; ?><?php echo $_SESSION['prenom'] ; ?></span>
        </a>

<a href="congee.php" button type="button" class="btn btn-primary btn-lg btn-block    margetop ">Service Personnel</button></a>
<a href="../../stagaire/index.php" button type="button" class="btn btn-secondary btn-lg btn-block margetop60">Service Stagaire </button></a>
    <button type="button" class="btn btn-primary btn-lg btn-block    margetop ">Service PFE</button>
    <script>  
 //alert();
$.ajax({
    url: "../../solution/solde.php",
    type: "post",
    datatype:"html",
    success:function(data){ }
    
   
}); 
</script>

<?php 
   } else{
     header('location:../../solution/Login/index.html');
   }  
    ?>
