<?php 
require_once('connexiondb.php');

$idf=isset($_GET['idF'])?$_GET['idF']:0;


           
$requete="select * from filiere where id_filiere=$idf";
$resultat=$pdo->query($requete);
$filiere=$resultat->fetch();
$nomf= $filiere['nomfiliere'];
$niveau= $filiere['niveau'];
    ?>

<!DOCTYPE HTML>
<html>
    <head>
        <meta charest="utf-a">
        <tit>Edition d'une filiére </tit>
        <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
         <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
    </head>
    <body>
        <?php include("menu.php");?>
         <div class="container">
         <div class="panel panel-primary margetop" >
            <div class="panel-heading">edition la filiére </div>
           
             <div class ="panel-body">
                <form method="post" action="updatefiliere.php" class="form" >
                <div class ="form-group">
                    <label for="niveau">id  la filière:<?php echo $idf ?></label>
                <input type="hidden" name="idF"  class="form-control " value="<?php echo $idf ?>"/></div>
                     <div class ="form-group">
                    <label for="niveau">Nom de la filière:</label>
                <input type="text" name="nomF"  class="form-control" value="<?php echo $nomf?>"/> 
                    </div>
                    <div class="form-group">
                <label for="niveau">Niveau:</label>
                <select name="niveau" class="form-control" id="niveau">
                    
                   
                     <option value="1ER"<?php if($niveau==="1ER") echo "selected" ?>>1ER </option>
                     <option value="2EME"<?php if($niveau==="2EME") echo "selected" ?>>2EME </option>
                     <option value="M"<?php if($niveau==="M" )echo "selected" ?>>Master </option>
                    <option value="N"<?php if($niveau==="N") echo "selected" ?>>Ingenieure </option>
                </select>
                    </div>
                
                    
                <button type ="submit" class="btn btn-success"><span class ="glyphicon glyphicon-save"></span>Enregister..</button> 
            
                </form>
             
            </div>
           
        </div>    
        </div>
    </body>
</html>
