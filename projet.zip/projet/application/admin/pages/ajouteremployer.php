<! DOCTYPE HTML>
<html>
<head>
  <meta charset="utf-8">
    <title>Nouveau employer</title>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/monstyle.css">
    </head>
<body> 
    <?php include("menu.php");?>
    <div class="container">
                <div class="panel panel-primary  margetop " >
           
                <div class="panel-heading">Saisir les doneés de nouveau employer</div>
        <div class="panel-body"> 
            <form method="POST" action="../../backend/codes/insertemployer.php"  class="form">
                
                <div class="form-group">
                    <label for="nom">Matricule de l'employer:</label>
            <input type="number" name="matricule" placeholder="matricule" class="form-control"/></div>
                <div class="form-group">
           <label for="nom">Nom de l'employer:</label>
            <input type="text" name="nom" placeholder="nom" class="form-control" required size="64" maxLength="15" minLength="3"  /></div>
          
                <div class="form-group">
             <label for="nom">Prenom de l'employer:</label>
            <input type="text" name="prenom" placeholder="prenom" class="form-control"  required size="64" maxLength="15" minLength="3"/></div>
                <div class="form-group">
          
               <label for="nom">Adresse de l'employer:</label>
            <input type="text" name="adresse" placeholder="adresse" class="form-control"  required size="64" maxLength="15" minLength="3"/></div>
                
                     <div class="form-group">
                 <label for="nom">telephone</label>
            <input type="number" name="telephone" placeholder="telephone" class="form-control" required size="64" maxLength="15" minLength="3"/></div>
                                       
                <div class="form-group">
                   <label for="nom">date_naissance de l'employer:</label>
            <input type="date" name="date_naissance" placeholder="date_naissance" class="form-control"  id="party"  min="1960-01-01" max="2002-01-01"  name="date_naissance"  /></div>
                
                <div class="form-group">
          <label for="nom">email de l'employer:</label>
            <input type="text" name="email" placeholder="email" class="form-control"  pattern=".+@gmail.com" size="30" id="email"  size="64" maxLength="64" /></div>
                
                <div class="form-group">
          <label for="nom">grade de l'employer:</label>
            <input type="text" name="grade" placeholder="grade" class="form-control" required size="64" maxLength="15" minLength="3" /></div>
                
                <div class="form-group">
          <label for="nom">date de recrutement l'employer:</label>
            <input type="date" name="daterecrut" placeholder="daterecrut" class="form-control"  /></div>
          
                           <div class="form-group">               
                      <button type="submit"   value="Enregistrer" class="btn btn-success">  
                <span class="glyphicon glyphicon-save" >
                </span> Enregister </button></div></form>
    </div>

    </body>


</html>